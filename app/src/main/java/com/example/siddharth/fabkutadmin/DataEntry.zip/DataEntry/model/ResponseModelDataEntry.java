package com.example.siddharth.fabkutadmin.DataEntry.model;

import java.util.ArrayList;

/**
 * Created by abhi on 26/06/17.
 */

public class ResponseModelDataEntry {
    private ArrayList<ResponseModelDataEntryData> data;

    public ArrayList<ResponseModelDataEntryData> getData() {
        return data;
    }

    public void setData(ArrayList<ResponseModelDataEntryData> data) {
        this.data = data;
    }
}