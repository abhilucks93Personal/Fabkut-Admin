package com.example.siddharth.fabkutadmin.DataEntry.model;

/**
 * Created by abhi on 26/06/17.
 */

public class ModelDataEntry {

  //  private int user_id;

    private int city_id=1;

    private int location_id=1;

    private String business_Name = "Test Saloon";

    private String contact_No="9599722268";

    private String contact_No1="8791794675";

    private String address1="Test Address 1";

    private String address2="Test Address 2";

    private String address3="Test Address 3";

    private String Contact_Person="Abhishek Agarwal";

    private String Land_mark = "test";

    private String business_email_id="test@gmail.com";

    private String ForMarketing="1";

    private String request_type="Of";



    public int getCity_id() {
        return city_id;
    }

    public void setCity_id(int city_id) {
        this.city_id = city_id;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public String getBusiness_Name() {
        return business_Name;
    }

    public void setBusiness_Name(String business_Name) {
        this.business_Name = business_Name;
    }

    public String getContact_No() {
        return contact_No;
    }

    public void setContact_No(String contact_No) {
        this.contact_No = contact_No;
    }

    public String getContact_No1() {
        return contact_No1;
    }

    public void setContact_No1(String contact_No1) {
        this.contact_No1 = contact_No1;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getContact_Person() {
        return Contact_Person;
    }

    public void setContact_Person(String contact_Person) {
        Contact_Person = contact_Person;
    }

    public String getLand_mark() {
        return Land_mark;
    }

    public void setLand_mark(String land_mark) {
        Land_mark = land_mark;
    }

    public String getBusiness_email_id() {
        return business_email_id;
    }

    public void setBusiness_email_id(String business_email_id) {
        this.business_email_id = business_email_id;
    }

    public String getForMarketing() {
        return ForMarketing;
    }

    public void setForMarketing(String forMarketing) {
        ForMarketing = forMarketing;
    }

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }
}
