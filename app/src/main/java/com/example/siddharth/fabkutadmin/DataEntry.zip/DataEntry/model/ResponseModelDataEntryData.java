package com.example.siddharth.fabkutadmin.DataEntry.model;

/**
 * Created by abhi on 26/06/17.
 */

class ResponseModelDataEntryData {

    private String assign;

    private String request_type;

    private String ForMarketing;

    private String business_Name;

    private String address1;

    private String Land_mark;

    private String address2;

    private String address3;

    private String location_Id;

    private String business_email_id;

    private String b_Target_id;

    private String computed;

    private String city_Id;

    private String Contact_Person;

    private String active;

    private String user_id;

    private String contact_No;

    private String contact_No1;

    public String getAssign() {
        return assign;
    }

    public void setAssign(String assign) {
        this.assign = assign;
    }

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }

    public String getForMarketing() {
        return ForMarketing;
    }

    public void setForMarketing(String forMarketing) {
        ForMarketing = forMarketing;
    }

    public String getBusiness_Name() {
        return business_Name;
    }

    public void setBusiness_Name(String business_Name) {
        this.business_Name = business_Name;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getLand_mark() {
        return Land_mark;
    }

    public void setLand_mark(String land_mark) {
        Land_mark = land_mark;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getLocation_Id() {
        return location_Id;
    }

    public void setLocation_Id(String location_Id) {
        this.location_Id = location_Id;
    }

    public String getBusiness_email_id() {
        return business_email_id;
    }

    public void setBusiness_email_id(String business_email_id) {
        this.business_email_id = business_email_id;
    }

    public String getB_Target_id() {
        return b_Target_id;
    }

    public void setB_Target_id(String b_Target_id) {
        this.b_Target_id = b_Target_id;
    }

    public String getComputed() {
        return computed;
    }

    public void setComputed(String computed) {
        this.computed = computed;
    }

    public String getCity_Id() {
        return city_Id;
    }

    public void setCity_Id(String city_Id) {
        this.city_Id = city_Id;
    }

    public String getContact_Person() {
        return Contact_Person;
    }

    public void setContact_Person(String contact_Person) {
        Contact_Person = contact_Person;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getContact_No() {
        return contact_No;
    }

    public void setContact_No(String contact_No) {
        this.contact_No = contact_No;
    }

    public String getContact_No1() {
        return contact_No1;
    }

    public void setContact_No1(String contact_No1) {
        this.contact_No1 = contact_No1;
    }
}
