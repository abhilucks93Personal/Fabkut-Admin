package com.example.siddharth.fabkutadmin.DataEntry.view;

import android.app.ActionBar;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.siddharth.fabkutadmin.DataEntry.model.ModelDataEntry;
import com.example.siddharth.fabkutadmin.DataEntry.model.ResponseCity;
import com.example.siddharth.fabkutadmin.R;
import com.example.siddharth.fabkutadmin.retrofit.RetrofitApi;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;
import static com.example.siddharth.fabkutadmin.R.id.spinner1;

public class DataEntry extends AppCompatActivity implements View.OnClickListener, RetrofitApi.ResponseListener {

    View actionBarView;
    TextView tvTitle;
    ImageView iconLeft;
    TextView tvSubmit;
    EditText etSalonName, etName,etContact, etEmail,etOffice,etLocation,etLandMark;
    Spinner spinnerCity,spinnerLocation;
    ModelDataEntry modelDataEntry = new ModelDataEntry();
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dataentry);
        preferences = this.getApplicationContext().getSharedPreferences("CreateLogin", Context.MODE_PRIVATE);

        RetrofitApi.getInstance().cityApiMethod(this,this);

        setActionBarView();
        findViewById();
        preferences = getSharedPreferences("CreateLogin",MODE_PRIVATE);
        editor = preferences.edit();
        editor.putString("flag","data");
        editor.commit();


        String getName = preferences.getString("UserName",null);
        etName.setText(getName);

    }

    private void findViewById() {
        tvTitle = (TextView) actionBarView.findViewById(R.id.actionbar_view_title);
        tvTitle.setText("Data Entry");

        iconLeft = (ImageView) actionBarView.findViewById(R.id.actionbar_view_icon_left);
        iconLeft.setImageDrawable(getResources().getDrawable(R.drawable.rectangle4));
        iconLeft.setVisibility(View.VISIBLE);
        iconLeft.setOnClickListener(this);

        etSalonName = (EditText) findViewById(R.id.activity_dataentry_salon_name);
        etName = (EditText) findViewById(R.id.activity_dataentry_contact_name);
        etContact = (EditText) findViewById(R.id.activity_dataentry_contact_no);
        etEmail = (EditText) findViewById(R.id.activity_dataentry_email);
        etOffice = (EditText) findViewById(R.id.activity_dataentry_office_no);
        etLocation = (EditText) findViewById(R.id.activity_dataentry_street);
        etLandMark = (EditText) findViewById(R.id.activity_dataentry_landmark);

        spinnerCity = (Spinner) findViewById(R.id.spinner_city);
        spinnerLocation = (Spinner) findViewById(R.id.spinner_location);
        tvSubmit = (TextView) findViewById(R.id.tv_submit);

        tvSubmit.setOnClickListener(this);
       // spinnerCity.setOnItemClickListener(this);
       // spinnerLocation.setOnClickListener(this);
    }




    private void setActionBarView() {

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.actionbar_view_custom);
        actionBarView = getSupportActionBar().getCustomView();
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.actionbar_view_icon_left:
                finish();
                break;
           /* case R.id.spinner_city:
                getCity();
            case R.id.spinner_location:
                 getLocation();
           */ case R.id.tv_submit:
                fetchData();
                break;
        }
    }



    private void fetchData() {
        modelDataEntry.setBusiness_Name("Fabkut Saloon");
        RetrofitApi.getInstance().dataEntryApiMethod(this, this, modelDataEntry);   // what is 2nd this???
    }






    @Override
    public void _onNext(Object obj) {
        ResponseCity responseCity = (ResponseCity) obj;
        Log.d("abc ", "" + responseCity);
        //responseCity.getMESSAGE();
        //ArrayAdapter<ResponseCity>
        //final ResponseCity responseCity1=new ResponseCity();
        //

            List<String> item = new ArrayList<String>();
        for (int i = 0; i<2; i++)
            item.add(responseCity.getData().get(i).getCity_Name());

            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, item);

            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerCity.setAdapter(dataAdapter);

    }


    @Override
    public void _onCompleted() {



    }
    @Override
    public void _onError(Throwable e) {
        Log.e("tag", e.getMessage());
    }
}
